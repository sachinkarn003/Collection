package com.company;

import java.util.HashMap;
import java.util.Map;

public class MAP {
    public static void main (String[] args){
        Map<String, String> language = new HashMap<>();

        if (language.containsKey("Java")){
            System.out.println("Java is already exists");
        }
        else{
            language.put("Java","a complied high level, object oriented, platform independent language");
            System.out.println("Java successfully added");
        }


        language.put("Python","an interpreted, object oriented, high level programming language with dynamic semantics");
        language.put("Algol","an Algorithmic language");
        System.out.println(language.put("BASIC","Beginner All Purpose Symbolic Instruction Code"));
        System.out.println(language.put("Lisp","Therein lies madness"));

//        System.out.println(language.get("Java"));
        if (language.containsKey("Java")){
            System.out.println("Java is already in map");
        }
        else{
            language.put("java","this course is about java");
        }
        System.out.println("=========================================================================");

       // language.remove("Lisp");
        if (language.remove("Algol","an Algorithmic language")){
            System.out.println( "Algol removed");
        }
        else{
            System.out.println("Algol not remove, key/value pair not found 404.");
        }

          if (language.replace("Lisp","Therein lies madness","a functional programming language with imperative features")){
              System.out.println("Lisp replaced");
          }
          else{
              System.out.println("Lisp was not replaced");
          }

            for (String key: language.keySet()){
                System.out.println(key+" : "+ language.get(key));
            }
    }
}
